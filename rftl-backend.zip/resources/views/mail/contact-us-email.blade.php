<table>
    <tbody>
    <tr>
        <th>Full Name</th>
        <td>{{ $name }}</td>
    </tr>
    <tr>
        <th>Email</th>
        <td>{{ $email }}</td>
    </tr>
    <tr>
        <th>Phone</th>
        <td>{{ $phone }}</td>
    </tr>
    <tr>
        <th>Message</th>
        <td>{{ $contactUsMessage }}</td>
    </tr>
    <tr>
        <th>Time</th>
        <td>{{ $timestamp }}</td>
    </tr>
    </tbody>
</table>
